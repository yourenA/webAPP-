'use strict';

var name = 'Node.js';
var s = `Hello, ${name}!`;

console.log(s);

