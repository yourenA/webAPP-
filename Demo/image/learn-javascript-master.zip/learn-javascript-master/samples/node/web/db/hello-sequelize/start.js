require('babel-core/register')({
    presets: ['stage-3']
});

require('./app.js');
